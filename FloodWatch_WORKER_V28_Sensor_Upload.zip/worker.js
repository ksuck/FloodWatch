// FloodWatch v2 — Cloudflare Worker + D1 + Static Assets
// Required: DB, DEVICE_TOKEN. Optional LINE_CHANNEL_ACCESS_TOKEN fallback; dashboard LINE token stored in D1.
// WARNING: Dashboard write endpoints are public without ADMIN_TOKEN.
const DEVICE = 'FLOOD-001';
const DEFAULT_LINE_TEMPLATE = 'ระดับผิวน้ำ {ผิวระดับน้ำ} cm\nน้ำสูงขึ้น {น้ำสูงขึ้น} cm\nน้ำเริ่มต้น {น้ำเริ่มต้น} cm\nระดับความเสี่ยง {ระดับความเสี่ยง}\n{เวลา}';
const json = (v, status = 200) => new Response(JSON.stringify(v), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' } });
const auth = (r, token, h = 'authorization') => Boolean(token && token.length >= 20 && (r.headers.get(h) || '') === (h === 'authorization' ? 'Bearer ' + token : token));
const defaults = { dashboard_refresh_seconds: 15, heartbeat_seconds: 1, sensor_upload_seconds: 60, offline_seconds: 10, alert_source: 'zero', thresholds: [{ name: 'เฝ้าระวัง', cm: 10 }, { name: 'เตือนภัย', cm: 25 }, { name: 'อันตราย', cm: 35 }], line: { enabled: false, to: '', cooldown_minutes: 5, message_template: DEFAULT_LINE_TEMPLATE } };
async function settings(env) {
  const entries = await env.DB.prepare('SELECT key,value FROM settings WHERE device_id=?').bind(DEVICE).all();
  const obj = structuredClone(defaults);
  for (const { key, value } of entries.results || []) {
    try {      
const val = JSON.parse(value); if (key === 'heartbeat_seconds' || key === 'offline_seconds') obj[key] = val;
      if (key === 'sensor_upload_seconds' && Number.isInteger(val) && val >= 5 && val <= 86400) obj.sensor_upload_seconds = val;
      if (key === 'dashboard_refresh_seconds' && Number.isSafeInteger(val) && val >= 5) obj.dashboard_refresh_seconds = val;
      if (key === 'alert_source' && (val === 'zero' || val === 'distance')) obj.alert_source = val; if (key === 'thresholds') obj.thresholds = normalizedThresholds(val); if (key === 'line') obj.line = val;    
} catch { }
  }
  return obj;
}
async function getLineToken(env) {
  const row = await env.DB.prepare('SELECT value FROM settings WHERE device_id=? AND key=?').bind(DEVICE, 'line:channel_access_token').first();
  if (row) { try { const v=JSON.parse(row.value); if(typeof v==='string' && v) return v; } catch {} }
  return env.LINE_CHANNEL_ACCESS_TOKEN || '';
}
async function patchSettings(env, input) {
  const old = await settings(env); const next = structuredClone(old);
  const entries = [];
  if (Object.hasOwn(input, 'heartbeat_seconds') || Object.hasOwn(input, 'offline_seconds')) {
    const heart = input.heartbeat_seconds ?? old.heartbeat_seconds;
    const offline = input.offline_seconds ?? old.offline_seconds;
    if (!Number.isInteger(heart) || heart < 1 || heart > 300 || !Number.isInteger(offline) || offline < Math.max(5, heart * 2) || offline > 900) throw Error('Invalid heartbeat/offline values');
    next.heartbeat_seconds = heart; next.offline_seconds = offline;
    entries.push(['heartbeat_seconds', heart], ['offline_seconds', offline]);
  }
  if (Object.hasOwn(input, 'sensor_upload_seconds')) {
    const seconds = input.sensor_upload_seconds;
    if (!Number.isInteger(seconds) || seconds < 5 || seconds > 86400) throw Error('Invalid sensor upload interval (5–86400 seconds)');
    next.sensor_upload_seconds = seconds;
    entries.push(['sensor_upload_seconds', seconds]);
  }
  if (Object.hasOwn(input, 'dashboard_refresh_seconds')) {
    const seconds = input.dashboard_refresh_seconds;
    if (!(Number.isSafeInteger(seconds) && seconds >= 5)) throw Error('Invalid dashboard refresh interval');
    next.dashboard_refresh_seconds = seconds;
    entries.push(['dashboard_refresh_seconds', seconds]);
  }
  if (Object.hasOwn(input, 'thresholds')) {
    const t = input.thresholds;
    const sorted = normalizedThresholds(t);
    if (!Array.isArray(t) || !sorted.length || sorted.length > 8 || sorted.some((v, i) => typeof v.name !== 'string' || !v.name.trim() || v.name.length > 40 || !Number.isFinite(v.cm) || v.cm <= 0 || v.cm > 10000 || (i > 0 && v.cm === sorted[i - 1].cm))) throw Error('Invalid thresholds: 1–8 distinct levels');
    next.thresholds = sorted; entries.push(['thresholds', sorted]);
  }
  if (Object.hasOwn(input, 'alert_source')) {
    if (!['zero','distance'].includes(input.alert_source)) throw Error('Invalid alert source');
    next.alert_source = input.alert_source; entries.push(['alert_source',input.alert_source]);
  }
  if (Object.hasOwn(input, 'line')) {
    const l = input.line;
    if (!l || typeof l.enabled !== 'boolean' || !Number.isInteger(l.cooldown_minutes) || l.cooldown_minutes < 5 || l.cooldown_minutes > 1440) throw Error('Invalid LINE settings');
    const template = l.message_template ?? old.line.message_template ?? DEFAULT_LINE_TEMPLATE;
    if (typeof template !== 'string' || !template.trim() || template.length > 1000) throw Error('Invalid LINE message template');
    const unknown = [...template.matchAll(/\{([^{}]+)\}/g)].map(m => m[1]).filter(x => !['ระดับน้ำ', 'ระดับความเสี่ยง', 'อุปกรณ์', 'เวลา', 'ผิวระดับน้ำ', 'น้ำสูงขึ้น', 'น้ำเริ่มต้น'].includes(x));
    if (unknown.length) throw Error('Unknown LINE variable: ' + unknown.join(', '));
    next.line = { enabled: l.enabled, to: '', cooldown_minutes: l.cooldown_minutes, message_template: template }; entries.push(['line', next.line]);
  }
  if (Object.hasOwn(input, 'line_channel_access_token')) {
    const token = input.line_channel_access_token;
    if (typeof token !== 'string' || token.trim().length < 20 || token.length > 4096 || /[\r\n]/.test(token)) throw Error('Invalid LINE Channel Access Token');
    entries.push(['line:channel_access_token', token.trim()]);
  }
  if (!entries.length) throw Error('No settings supplied');
  await env.DB.batch(entries.map(([k, v]) => env.DB.prepare(`INSERT INTO settings(device_id,key,value) VALUES (?,?,?) ON CONFLICT(device_id,key) DO UPDATE SET value=excluded.value`).bind(DEVICE, k, JSON.stringify(v))));
  if (entries.some(([k]) => k === 'heartbeat_seconds' || k === 'offline_seconds' || k === 'sensor_upload_seconds')) {
    const version = Date.now();
    await env.DB.prepare(`INSERT INTO settings(device_id,key,value) VALUES (?,?,?) ON CONFLICT(device_id,key) DO UPDATE SET value=excluded.value`).bind(DEVICE,'device:heartbeat_config_version',JSON.stringify(version)).run();
  }
  // Keep last notification timestamp across settings changes to enforce cooldown.

  return next;
}
// Zero belongs exclusively to D1 settings. Never trust baseline fields from the device.
async function zeroBaseline(env) {
  const r=await env.DB.prepare('SELECT value FROM settings WHERE device_id=? AND key=?').bind(DEVICE,'zero:base_cm').first();
  if(!r)return null;
  try { const n=JSON.parse(r.value); return Number.isFinite(n)&&n>=25&&n<=450?n:null; } catch { return null; }
}
function withZero(reading,base) {
  const valid=reading?.sensor_ok===true || reading?.sensor_ok===1;
  const distance=reading?.distance_cm;
  return {...reading,base_cm:base,zero_set:base!==null,level_cm:valid&&base!==null&&Number.isFinite(distance)?base-distance:null};
}
function normalizedThresholds(t) {
  if (Array.isArray(t)) return t.map(x => ({ name: String(x?.name ?? ''), cm: x?.cm })).sort((a, b) => a.cm - b.cm);
  if (t && [t.watch, t.warn, t.danger].every(Number.isFinite)) return [{ name: 'เฝ้าระวัง', cm: t.watch }, { name: 'เตือนภัย', cm: t.warn }, { name: 'อันตราย', cm: t.danger }];
  return [];
}
function risk(cm, t) { if (!Number.isFinite(cm)) return -1; return normalizedThresholds(t).filter(x => cm >= x.cm).length; }
async function notifyOnThreshold(env, reading, previous, config, ctx) {
  const l = config.line;
  if (!l.enabled) return;
  const lineToken = await getLineToken(env);
  if (!lineToken) return;
  const useZero = (config.alert_source || 'zero') === 'zero';
  const measure = useZero ? reading.level_cm : reading.distance_cm;
  const prevMeasure = useZero ? previous?.level_cm : previous?.distance_cm;
  if (!reading.sensor_ok || (useZero && !reading.zero_set) || !Number.isFinite(measure)) return;
  const getSeverity = value => !Number.isFinite(value) ? -1 :
    normalizedThresholds(config.thresholds).filter(x => useZero ? value >= x.cm : value <= x.cm).length;
  const severity = getSeverity(measure);
  if (severity < 1) return;
  const prior = previous?.sensor_ok && (!useZero || previous?.zero_set) ? getSeverity(prevMeasure) : -1;
  const enteredOrEscalated = prior < severity;
  const now = Math.floor(Date.now() / 1000);
  // Immediate on crossing a threshold; repeat only after configured interval while above threshold.
  // Atomic D1 conditional update prevents duplicate sends from concurrent readings.
  const key = 'line:notice_state';
  await env.DB.prepare('INSERT OR IGNORE INTO settings(device_id,key,value) VALUES (?,?,?)').bind(DEVICE, key, JSON.stringify({ at: 0, severity: 0 })).run();
  const current = await env.DB.prepare('SELECT value FROM settings WHERE device_id=? AND key=?').bind(DEVICE, key).first();
  if (!current) return;
  let last = { at: 0, severity: 0 }; try { last = JSON.parse(current.value) } catch { }
  const lastAt = Number(last.at) || 0;
  const lastSeverity = Number(last.severity) || 0;
  const immediate = severity > lastSeverity && lastAt > 0; // Only an actual escalation bypasses cooldown
  const due = now - lastAt >= l.cooldown_minutes * 60;
  if (!immediate && !due) return;
  const next = JSON.stringify({ at: now, severity });
  const lock = await env.DB.prepare('UPDATE settings SET value=? WHERE device_id=? AND key=? AND value=?').bind(next, DEVICE, key, current.value).run();
  if (!lock.meta?.changes) return;
  const levels = normalizedThresholds(config.thresholds);
  const name = levels[severity - 1]?.name || 'แจ้งเตือน';
  const time = new Date().toLocaleString('th-TH', { timeZone: 'Asia/Bangkok', hour12: false });
  const variables = { 'ผิวระดับน้ำ': Number(reading.distance_cm.toFixed(1)).toString(), 'น้ำสูงขึ้น': Number.isFinite(reading.level_cm) ? Number(reading.level_cm.toFixed(1)).toString() : 'ยังไม่ตั้ง Zero', 'น้ำเริ่มต้น': Number.isFinite(reading.base_cm) ? Number(reading.base_cm.toFixed(1)).toString() : 'ยังไม่ตั้ง Zero', 'ระดับน้ำ': Number(measure.toFixed(1)).toString(), 'ระดับความเสี่ยง': name, 'อุปกรณ์': DEVICE, 'เวลา': time };
  const message = (l.message_template || DEFAULT_LINE_TEMPLATE).replace(/\{(ระดับน้ำ|ระดับความเสี่ยง|อุปกรณ์|เวลา|ผิวระดับน้ำ|น้ำสูงขึ้น|น้ำเริ่มต้น)\}/g, (_, k) => variables[k]);
  const payload = { messages: [{ type: 'text', text: message }] };
  ctx.waitUntil((async () => {
    let ok = false, detail = '';
    try {
      const r = await fetch('https://api.line.me/v2/bot/message/broadcast', { method: 'POST', headers: { 'Authorization': `Bearer ${lineToken}`, 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      ok = r.ok; detail = 'HTTP ' + r.status;
    } catch (e) { detail = String(e).slice(0, 200) }
    if (!ok) {
      // Release reservation only if nobody else has updated it meanwhile.
      await env.DB.prepare('UPDATE settings SET value=? WHERE device_id=? AND key=? AND value=?').bind(current.value, DEVICE, key, next).run();
    }
    await env.DB.prepare('INSERT INTO alert_logs(device_id,severity,level_cm,success,detail,created_at) VALUES (?,?,?,?,?,unixepoch())').bind(DEVICE, severity, reading.level_cm ?? null, ok ? 1 : 0, detail).run();
  })());
}

export default {  
async fetch(request, env, ctx) {
    const url = new URL(request.url), path = url.pathname;
    // Dashboard origin is fixed here: no DASHBOARD_ORIGIN environment variable required.
    const origin = request.headers.get('Origin');
    const DASHBOARD_URL = 'https://floodwatch.pakphanang-school.workers.dev';
    const allowedOrigin = origin === DASHBOARD_URL;
    const cors = allowedOrigin ? {
      'Access-Control-Allow-Origin': DASHBOARD_URL,
      'Access-Control-Allow-Methods': 'GET,POST,PUT,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      'Vary': 'Origin'
    } : { 'Vary': 'Origin' };
    // Browser preflight is only approved for the actual FloodWatch dashboard.
    if (request.method === 'OPTIONS') return new Response(null, { status: allowedOrigin ? 204 : 403, headers: cors });
    // Reject untrusted browser origins; requests without Origin (such as ESP32)
    // continue through their existing device/admin token authentication.
    if (origin && !allowedOrigin) return new Response(JSON.stringify({ error: 'origin not allowed' }), {
      status: 403, headers: { 'Content-Type': 'application/json; charset=utf-8', ...cors }
    });
    // Add CORS headers to all responses, including errors.
    const respond = async () => {

      try {
        if (path === '/api/zero' && request.method === 'POST') {
          const d=await request.json();
          if(d.device_id!==DEVICE || !['set_zero','clear_zero'].includes(d.action))return json({error:'invalid zero action'},400);
          if(d.action==='clear_zero'){
            await env.DB.batch([
              env.DB.prepare('DELETE FROM settings WHERE device_id=? AND key=?').bind(DEVICE,'zero:base_cm'),
              env.DB.prepare('SELECT 1')
            ]);
            return json({ok:true,zero_set:false,base_cm:null,level_cm:null});
          }
          // A fresh, valid D1 measurement is required; never set Zero from a stale/offline reading.
          const row=await env.DB.prepare('SELECT distance_cm,sensor_ok,received_at FROM readings WHERE device_id=? ORDER BY id DESC LIMIT 1').bind(DEVICE).first();
          const hb=await env.DB.prepare('SELECT last_seen FROM device_heartbeat WHERE device_id=?').bind(DEVICE).first();
          const cfg=await settings(env); const now=Math.floor(Date.now()/1000);
          if(!row || !row.sensor_ok || !Number.isFinite(row.distance_cm) || !hb || now-hb.last_seen>cfg.offline_seconds || now-row.received_at>cfg.offline_seconds)
            return json({error:'no fresh online measurement for Zero'},409);
          const base=row.distance_cm;
          await env.DB.batch([
            env.DB.prepare('INSERT INTO settings(device_id,key,value) VALUES (?,?,?) ON CONFLICT(device_id,key) DO UPDATE SET value=excluded.value').bind(DEVICE,'zero:base_cm',JSON.stringify(base)),
            env.DB.prepare('SELECT 1')
          ]);
          return json({ok:true,zero_set:true,base_cm:base,level_cm:0});
        }
        if (path === '/api/settings' && request.method === 'GET') {
          if (url.searchParams.get('device') !== DEVICE) return json({ error: 'unknown device' }, 404);
          return json({...(await settings(env)), line_token_configured: !!(await getLineToken(env))});
        }
        if (path === '/api/line/test' && request.method === 'POST') {
          // Public test endpoint: broadcast consumes LINE OA quota.
          const lineToken=await getLineToken(env);
          if (!lineToken) return json({error:'LINE token not configured'},409);
          const payload={messages:[{type:'text',text:'FloodWatch: ทดสอบส่งแจ้งเตือน LINE Broadcast สำเร็จจากระบบ (ข้อความทดสอบ)'}]};
          const r=await fetch('https://api.line.me/v2/bot/message/broadcast',{method:'POST',headers:{'Authorization':`Bearer ${lineToken}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});
          if(!r.ok) return json({ok:false,error:'LINE rejected broadcast',line_status:r.status,detail:(await r.text()).slice(0,350)},502);
          return json({ok:true,message:'LINE accepted test broadcast; delivery depends on recipient eligibility'});
        }
        if (path === '/api/settings' && request.method === 'PUT') {
          if (url.searchParams.get('device') !== DEVICE) return json({ error: 'unknown device' }, 404);
          const input = await request.json();
          try { return json({...(await patchSettings(env, input)),line_token_configured:!!(await getLineToken(env))}); } catch (e) { return json({ error: e.message }, 400); }
        }
        if (path === '/api/device-config' && request.method === 'GET') {
          if (!auth(request, env.DEVICE_TOKEN)) return json({ error: 'unauthorized' }, 401);
          if (url.searchParams.get('device') !== DEVICE) return json({ error: 'unknown device' }, 404);
          const c = await settings(env); const v=await env.DB.prepare('SELECT value FROM settings WHERE device_id=? AND key=?').bind(DEVICE,'device:heartbeat_config_version').first(); return json({ heartbeat_seconds: c.heartbeat_seconds, sensor_upload_seconds: c.sensor_upload_seconds, config_version: v ? JSON.parse(v.value) : 0 });
        }
        if (path === '/api/config-status' && request.method === 'GET') {
          if(url.searchParams.get('device')!==DEVICE)return json({error:'unknown device'},404);
          const rows=await env.DB.prepare("SELECT key,value FROM settings WHERE device_id=? AND key IN ('device:heartbeat_config_version','device:heartbeat_applied','heartbeat_seconds','sensor_upload_seconds')").bind(DEVICE).all();
          const map=Object.fromEntries((rows.results||[]).map(r=>[r.key,JSON.parse(r.value)]));
          const requested=map['device:heartbeat_config_version']||0, applied=map['device:heartbeat_applied']||null;
          return json({requested_version:requested,applied_version:applied?.version||0,applied_seconds:applied?.seconds??null,applied_upload_seconds:applied?.upload_seconds??null,applied_at:applied?.at||null,confirmed:!!requested&&applied?.version===requested&&applied?.seconds===map['heartbeat_seconds']&&applied?.upload_seconds===(map['sensor_upload_seconds']??60)});
        }
        if (path === '/api/config-ack' && request.method === 'POST') {
          if(!auth(request,env.DEVICE_TOKEN))return json({error:'unauthorized'},401);
          const d=await request.json();
          if(d.device_id!==DEVICE||!Number.isSafeInteger(d.config_version)||d.config_version<0||!Number.isInteger(d.heartbeat_seconds)||d.heartbeat_seconds<1||d.heartbeat_seconds>300||!Number.isInteger(d.sensor_upload_seconds)||d.sensor_upload_seconds<5||d.sensor_upload_seconds>86400)return json({error:'bad config ack'},400);
          const current=await env.DB.prepare('SELECT value FROM settings WHERE device_id=? AND key=?').bind(DEVICE,'device:heartbeat_config_version').first();
          const version=current?JSON.parse(current.value):0;
          const c=await settings(env);
          if(d.config_version!==version||(d.heartbeat_seconds!==c.heartbeat_seconds||d.sensor_upload_seconds!==c.sensor_upload_seconds))return json({error:'stale config ack'},409);
          const applied={version,seconds:d.heartbeat_seconds,upload_seconds:d.sensor_upload_seconds,at:new Date().toISOString()};
          await env.DB.prepare('INSERT INTO settings(device_id,key,value) VALUES (?,?,?) ON CONFLICT(device_id,key) DO UPDATE SET value=excluded.value').bind(DEVICE,'device:heartbeat_applied',JSON.stringify(applied)).run();
          return json({ok:true,confirmed:true,config_version:version});
        }
        if (path === '/api/history' && request.method === 'GET') {
          if (url.searchParams.get('device') !== DEVICE) return json({ error: 'unknown device' }, 404);
          // Supports Bangkok calendar-day ranges using inclusive from and exclusive to (Unix seconds).
          // Retains hours=... for older dashboards and other existing clients.
          const limit = Number(url.searchParams.get('limit') || 1000);
          const offset = Number(url.searchParams.get('offset') || 0);
          const customRange = url.searchParams.has('from') || url.searchParams.has('to');
          const now = Math.floor(Date.now() / 1000);
          let from, to;
          if (customRange) {
            from = Number(url.searchParams.get('from'));
            to = Number(url.searchParams.get('to'));
          } else {
            const hours = Number(url.searchParams.get('hours') || 24);
            if (!Number.isInteger(hours) || hours < 1 || hours > 168) return json({ error: 'bad history hours' }, 400);
            from = now - hours * 3600;
            to = now + 1;
          }
          if (!Number.isInteger(limit) || limit < 1 || limit > 1500 ||
              !Number.isSafeInteger(offset) || offset < 0 || offset > 10000000 ||
              !Number.isSafeInteger(from) || !Number.isSafeInteger(to) ||
              from < 0 || to <= from || to - from > 366 * 86400)
            return json({ error: 'bad history range' }, 400);
          const count = await env.DB.prepare(
            'SELECT COUNT(*) AS total FROM readings WHERE device_id=? AND received_at>=? AND received_at<?'
          ).bind(DEVICE, from, to).first();
          const total = Number(count?.total || 0);
          const found = await env.DB.prepare(
            'SELECT seq,sensor_ok,distance_cm,base_cm,level_cm,zero_set,success_interval_ms,success_count,received_at FROM readings WHERE device_id=? AND received_at>=? AND received_at<? ORDER BY received_at DESC,id DESC LIMIT ? OFFSET ?'
          ).bind(DEVICE, from, to, limit, offset).all();
          // Most recent rows first, so page 1 always has the most recent measurements.
          const rows = (found.results || []).map(r => ({ ...r, received_at: new Date(r.received_at * 1000).toISOString() }));
          return json({ device_id: DEVICE, total, offset, limit, truncated: offset + rows.length < total, rows });
        }
        if (path === '/api/heartbeat' && request.method === 'POST') {
          if (!auth(request, env.DEVICE_TOKEN)) return json({ error: 'unauthorized' }, 401);
          const d = await request.json();
          if (d.device_id !== DEVICE) return json({ error: 'unknown device' }, 404);
          await env.DB.prepare('INSERT INTO device_heartbeat(device_id,last_seen) VALUES (?,unixepoch()) ON CONFLICT(device_id) DO UPDATE SET last_seen=excluded.last_seen').bind(DEVICE).run();
          return json({ ok: true });
        }
        if (path === '/api/reading' && request.method === 'POST') {
          if (!auth(request, env.DEVICE_TOKEN)) return json({ error: 'unauthorized' }, 401);
          const d = await request.json();
          if (d.device_id !== DEVICE || d.sensor_ok !== true || !Number.isInteger(d.seq) || d.seq < 1 || !Number.isInteger(d.boot_id) || d.boot_id < 1 || d.boot_id > 4294967295) return json({ error: 'bad payload' }, 400);
          if (d.sensor_ok && (!Number.isFinite(d.distance_cm) || d.distance_cm < 25 || d.distance_cm > 450)) return json({ error: 'invalid distance' }, 400);
          if (!Number.isInteger(d.success_interval_ms) || d.success_interval_ms < 0 || d.success_interval_ms > 4294967295) return json({ error: 'invalid success interval' }, 400);
          if (!Number.isInteger(d.success_count) || d.success_count < 1) return json({ error: 'invalid success count' }, 400);
          // Compatibility migration: older flood-db databases did not have boot_id.
          // Add the column once, without deleting historical readings or requiring a manual SQL step.
          const cols = await env.DB.prepare('PRAGMA table_info(readings)').all();
          if (!(cols.results || []).some(c => c.name === 'boot_id')) {
            try {
              await env.DB.prepare('ALTER TABLE readings ADD COLUMN boot_id INTEGER NOT NULL DEFAULT 0').run();
              console.log('[FloodWatch] readings.boot_id migration completed');
            } catch (migrationError) {
              // Concurrent requests can both try migration. Only ignore if the column now exists.
              const after = await env.DB.prepare('PRAGMA table_info(readings)').all();
              if (!(after.results || []).some(c => c.name === 'boot_id')) throw migrationError;
            }
          }
          // Idempotent per boot. A retried HTTPS POST must not duplicate rows or LINE alerts.
          const existing = await env.DB.prepare('SELECT id FROM readings WHERE device_id=? AND boot_id=? AND seq=? LIMIT 1').bind(DEVICE, d.boot_id, d.seq).first();
          if (existing) return json({ ok: true, duplicate: true });
          const previousRow = await env.DB.prepare('SELECT sensor_ok,distance_cm FROM readings WHERE device_id=? ORDER BY id DESC LIMIT 1').bind(DEVICE).first();
          const base = await zeroBaseline(env);
          const currentReading = withZero(d,base);
          const previous = previousRow ? withZero(previousRow,base) : null;
          const insertResult = await env.DB.prepare(`INSERT OR IGNORE INTO readings(device_id,boot_id,seq,sensor_ok,distance_cm,base_cm,level_cm,zero_set,failures,success_interval_ms,success_count,uptime_ms,received_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,unixepoch())`).bind(DEVICE, d.boot_id, d.seq, d.sensor_ok ? 1 : 0, d.sensor_ok ? d.distance_cm : null, base, currentReading.level_cm, base!==null ? 1 : 0, 0, d.success_interval_ms, d.success_count, Number(d.uptime_ms || 0)).run();
          if (!insertResult.meta?.changes) return json({ ok: true, duplicate: true });
          await env.DB.prepare('INSERT INTO device_heartbeat(device_id,last_seen) VALUES (?,unixepoch()) ON CONFLICT(device_id) DO UPDATE SET last_seen=excluded.last_seen').bind(DEVICE).run();
          const config = await settings(env);
          // Do not reset notice state when readings briefly leave the threshold.
          await notifyOnThreshold(env, currentReading, previous, config, ctx);
          return json({ ok: true });
        }
        if (path === '/api/state' && request.method === 'GET') {
          if (url.searchParams.get('device') !== DEVICE) return json({ error: 'unknown device' }, 404);
          const row = await env.DB.prepare('SELECT seq,sensor_ok,distance_cm,base_cm,level_cm,zero_set,success_interval_ms,success_count,received_at FROM readings WHERE device_id=? ORDER BY id DESC LIMIT 1').bind(DEVICE).first();
          const hb = await env.DB.prepare('SELECT last_seen FROM device_heartbeat WHERE device_id=?').bind(DEVICE).first();
          if (!row) { const b=await zeroBaseline(env); return json({ online: false, sensor_ok: false, reason: 'no readings',zero_set:b!==null,base_cm:b,level_cm:null }); }
          const config = await settings(env);
          const age = Math.max(0, Math.floor(Date.now() / 1000) - row.received_at), online = !!hb && (Math.floor(Date.now() / 1000) - hb.last_seen) <= config.offline_seconds;
          const derived=withZero(row,await zeroBaseline(env));
          return json({ online, sensor_ok: !!row.sensor_ok, zero_set: derived.zero_set, distance_cm: row.distance_cm, base_cm: derived.base_cm, level_cm: derived.level_cm, age_seconds: age, success_interval_ms: row.success_interval_ms, success_count: row.success_count, seq: row.seq, received_at: new Date(row.received_at * 1000).toISOString() });
        }
        if (path.startsWith('/api/')) return json({ error: 'not found' }, 404);
        return json({ service: 'FloodWatch API Worker', status: 'ready' });
      } catch (e) { console.error('[FloodWatch API]', path, e); return json({ error: 'internal error', endpoint: path, detail: path === '/api/reading' ? String(e?.message || e).slice(0, 240) : undefined }, 500); }
    };
    const response = await respond();
    const headers = new Headers(response.headers);
    Object.entries(cors).forEach(([k, v]) => headers.set(k, v));
    return new Response(response.body, { status: response.status, headers });
  }
};
