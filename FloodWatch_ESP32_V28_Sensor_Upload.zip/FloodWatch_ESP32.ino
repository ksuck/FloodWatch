/* FloodWatch ESP32 (classic ESP32 DevKit) — FreeRTOS + GPIO interrupt, nonblocking Echo.
   Arduino-ESP32 3.x, built-in WiFi/HTTPClient/Preferences/ArduinoJson.
   The SR04M-0 board MUST be confirmed in TRIG/ECHO mode. Never feed 5V ECHO to ESP32.
*/
#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include <WiFiClientSecure.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <math.h>
#include <time.h>

// Standard public CA roots (verify Cloudflare hostname chain supports one of these).
static const char API_CA_PEM[] = R"PEM(
-----BEGIN CERTIFICATE-----
MIIFVzCCAz+gAwIBAgINAgPlk28xsBNJiGuiFzANBgkqhkiG9w0BAQwFADBHMQsw
CQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExMQzEU
MBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMTYwNjIyMDAwMDAwWhcNMzYwNjIyMDAw
MDAwWjBHMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZp
Y2VzIExMQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwggIiMA0GCSqGSIb3DQEBAQUA
A4ICDwAwggIKAoICAQC2EQKLHuOhd5s73L+UPreVp0A8of2C+X0yBoJx9vaMf/vo
27xqLpeXo4xL+Sv2sfnOhB2x+cWX3u+58qPpvBKJXqeqUqv4IyfLpLGcY9vXmX7w
Cl7raKb0xlpHDU0QM+NOsROjyBhsS+z8CZDfnWQpJSMHobTSPS5g4M/SCYe7zUjw
TcLCeoiKu7rPWRnWr4+wB7CeMfGCwcDfLqZtbBkOtdh+JhpFAz2weaSUKK0Pfybl
qAj+lug8aJRT7oM6iCsVlgmy4HqMLnXWnOunVmSPlk9orj2XwoSPwLxAwAtcvfaH
szVsrBhQf4TgTM2S0yDpM7xSma8ytSmzJSq0SPly4cpk9+aCEI3oncKKiPo4Zor8
Y/kB+Xj9e1x3+naH+uzfsQ55lVe0vSbv1gHR6xYKu44LtcXFilWr06zqkUspzBmk
MiVOKvFlRNACzqrOSbTqn3yDsEB750Orp2yjj32JgfpMpf/VjsPOS+C12LOORc92
wO1AK/1TD7Cn1TsNsYqiA94xrcx36m97PtbfkSIS5r762DL8EGMUUXLeXdYWk70p
aDPvOmbsB4om3xPXV2V4J95eSRQAogB/mqghtqmxlbCluQ0WEdrHbEg8QOB+DVrN
VjzRlwW5y0vtOUucxD/SVRNuJLDWcfr0wbrM7Rv1/oFB2ACYPTrIrnqYNxgFlQID
AQABo0IwQDAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4E
FgQU5K8rJnEaK0gnhS9SZizv8IkTcT4wDQYJKoZIhvcNAQEMBQADggIBAJ+qQibb
C5u+/x6Wki4+omVKapi6Ist9wTrYggoGxval3sBOh2Z5ofmmWJyq+bXmYOfg6LEe
QkEzCzc9zolwFcq1JKjPa7XSQCGYzyI0zzvFIoTgxQ6KfF2I5DUkzps+GlQebtuy
h6f88/qBVRRiClmpIgUxPoLW7ttXNLwzldMXG+gnoot7TiYaelpkttGsN/H9oPM4
7HLwEXWdyzRSjeZ2axfG34arJ45JK3VmgRAhpuo+9K4l/3wV3s6MJT/KYnAK9y8J
ZgfIPxz88NtFMN9iiMG1D53Dn0reWVlHxYciNuaCp+0KueIHoI17eko8cdLiA6Ef
MgfdG+RCzgwARWGAtQsgWSl4vflVy2PFPEz0tv/bal8xa5meLMFrUKTX5hgUvYU/
Z6tGn6D/Qqc6f1zLXbBwHSs09dR2CQzreExZBfMzQsNhFRAbd03OIozUhfJFfbdT
6u9AWpQKXCBfTkBdYiJ23//OYb2MI3jSNwLgjt7RETeJ9r/tSQdirpLsQBqvFAnZ
0E6yove+7u7Y/9waLd64NnHi/Hm3lCXRSHNboTXns5lndcEZOitHTtNCjv0xyBZm
2tIMPNuzjsmhDYAPexZ3FL//2wmUspO8IFgV6dtxQ/PeEMMA3KgqlbbC1j+Qa3bb
bP6MvPJwNQzcmRk13NfIRmPVNnGuV/u3gm3c
-----END CERTIFICATE-----
-----BEGIN CERTIFICATE-----
MIIFazCCA1OgAwIBAgIRAIIQz7DSQONZRGPgu2OCiwAwDQYJKoZIhvcNAQELBQAw
TzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh
cmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMTUwNjA0MTEwNDM4
WhcNMzUwNjA0MTEwNDM4WjBPMQswCQYDVQQGEwJVUzEpMCcGA1UEChMgSW50ZXJu
ZXQgU2VjdXJpdHkgUmVzZWFyY2ggR3JvdXAxFTATBgNVBAMTDElTUkcgUm9vdCBY
MTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAK3oJHP0FDfzm54rVygc
h77ct984kIxuPOZXoHj3dcKi/vVqbvYATyjb3miGbESTtrFj/RQSa78f0uoxmyF+
0TM8ukj13Xnfs7j/EvEhmkvBioZxaUpmZmyPfjxwv60pIgbz5MDmgK7iS4+3mX6U
A5/TR5d8mUgjU+g4rk8Kb4Mu0UlXjIB0ttov0DiNewNwIRt18jA8+o+u3dpjq+sW
T8KOEUt+zwvo/7V3LvSye0rgTBIlDHCNAymg4VMk7BPZ7hm/ELNKjD+Jo2FR3qyH
B5T0Y3HsLuJvW5iB4YlcNHlsdu87kGJ55tukmi8mxdAQ4Q7e2RCOFvu396j3x+UC
B5iPNgiV5+I3lg02dZ77DnKxHZu8A/lJBdiB3QW0KtZB6awBdpUKD9jf1b0SHzUv
KBds0pjBqAlkd25HN7rOrFleaJ1/ctaJxQZBKT5ZPt0m9STJEadao0xAH0ahmbWn
OlFuhjuefXKnEgV4We0+UXgVCwOPjdAvBbI+e0ocS3MFEvzG6uBQE3xDk3SzynTn
jh8BCNAw1FtxNrQHusEwMFxIt4I7mKZ9YIqioymCzLq9gwQbooMDQaHWBfEbwrbw
qHyGO0aoSCqI3Haadr8faqU9GY/rOPNk3sgrDQoo//fb4hVC1CLQJ13hef4Y53CI
rU7m2Ys6xt0nUW7/vGT1M0NPAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNV
HRMBAf8EBTADAQH/MB0GA1UdDgQWBBR5tFnme7bl5AFzgAiIyBpY9umbbjANBgkq
hkiG9w0BAQsFAAOCAgEAVR9YqbyyqFDQDLHYGmkgJykIrGF1XIpu+ILlaS/V9lZL
ubhzEFnTIZd+50xx+7LSYK05qAvqFyFWhfFQDlnrzuBZ6brJFe+GnY+EgPbk6ZGQ
3BebYhtF8GaV0nxvwuo77x/Py9auJ/GpsMiu/X1+mvoiBOv/2X/qkSsisRcOj/KK
NFtY2PwByVS5uCbMiogziUwthDyC3+6WVwW6LLv3xLfHTjuCvjHIInNzktHCgKQ5
ORAzI4JMPJ+GslWYHb4phowim57iaztXOoJwTdwJx4nLCgdNbOhdjsnvzqvHu7Ur
TkXWStAmzOVyyghqpZXjFaH3pO3JLF+l+/+sKAIuvtd7u+Nxe5AW0wdeRlN8NwdC
jNPElpzVmbUq4JUagEiuTDkHzsxHpFKVK7q4+63SM1N95R1NbdWhscdCb+ZAJzVc
oyi3B43njTOQ5yOf+1CceWxG1bQVs5ZufpsMljq4Ui0/1lvh+wjChP4kqKOJ2qxq
4RgqsahDYVvTH9w7jXbyLeiNdd8XM2w9U/t7y0Ff/9yi0GE44Za4rF2LN9d11TPA
mRGunUHBcnWEvgJBQl9nJEiU0Zsnvgc/ubhPgXRR4Xq37Z0j4r7g1SgEEzwxA57d
emyPxgcYxn/eR44/KJ4EBs+lVDR3veyJm+kXQ99b21/+jh5Xos1AnX5iItreGCc=
-----END CERTIFICATE-----
)PEM";

// === EDIT THESE BEFORE FLASHING ===
// Configure router Wi-Fi from http://192.168.4.1 (credentials saved in NVS).
static const char* AP_SSID = "FloodWatch-Setup";
static const char* AP_PASS = "ChangeMe1234"; // CHANGE before flashing!
static const char* API_BASE = "https://floodwatch-api.pakphanang-school.workers.dev"; // no final slash
static const char* DEVICE_ID = "FLOOD-001";
static const char* DEVICE_TOKEN = "fw_7d4b9e2c8a61f035bce90417d2a8f63e5b190ca7d46e238f0a5c91b7e64d320a";
static const int TRIG_PIN = 5, ECHO_PIN = 18;
// Trigger/Echo board: 3.3V only if its variant operates reliably; 5V supply needs level shifting on ECHO.

static constexpr uint32_t SENSOR_PERIOD_MS = 250;
static constexpr uint32_t ECHO_TIMEOUT_US = 35000;
static uint32_t heartbeatPeriodMs = 1000;
static uint32_t readingSendPeriodMs = 60000UL; // configurable via /api/device-config (default 60 seconds)
static WebServer localWeb(80);
static String wifiSSID, wifiPassword;
static bool wifiCredentialsChanged = false;
static constexpr uint32_t CONFIG_PERIOD_MS = 30000;
static constexpr uint32_t COMMAND_PERIOD_MS = 1500;
static constexpr uint32_t WIFI_RETRY_MIN_MS = 15000;
static constexpr uint32_t WIFI_RETRY_MAX_MS = 60000;
static constexpr uint32_t READING_STALE_MS = 3000;
static constexpr float MIN_DISTANCE_CM = 25.0f, MAX_DISTANCE_CM = 450.0f;


struct Snapshot {
  float distance_cm = NAN;
  bool sensor_ok = false;
  uint32_t captured_ms = 0;
  uint32_t sequence = 0;
  uint32_t failures = 0;
  uint32_t success_interval_ms = 0;
  uint32_t success_count = 0;
  uint32_t last_good_ms = 0;
};

static Snapshot current;
static SemaphoreHandle_t stateMutex;
static Preferences prefs;
static SemaphoreHandle_t prefsMutex;
static uint32_t bootId = 0;
static uint32_t lastUploadAttempt = 0;
static uint32_t uploadBackoffMs = 1000;
static volatile uint32_t riseUs = 0, widthUs = 0;
static volatile bool gotRise = false, gotPulse = false, captureEnabled = false;
static portMUX_TYPE echoMux = portMUX_INITIALIZER_UNLOCKED;
static uint32_t sensorAttempts = 0;
static uint32_t totalFailures = 0;

bool copySnapshot(Snapshot& out) {
  if(xSemaphoreTake(stateMutex,pdMS_TO_TICKS(50))!=pdTRUE) return false;
  out=current; xSemaphoreGive(stateMutex); return true;
}
void IRAM_ATTR echoEdgeISR() {
  const uint32_t now = micros();
  const bool high = digitalRead(ECHO_PIN);
  portENTER_CRITICAL_ISR(&echoMux);
  if (captureEnabled) {
    if (high) { riseUs = now; gotRise = true; }
    else if (gotRise) {
      widthUs = now - riseUs;
      gotPulse = true;
      captureEnabled = false;
    }
  }
  portEXIT_CRITICAL_ISR(&echoMux);
}


void publishReading(float cm, uint32_t failures) {
  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(50)) != pdTRUE) return;
  uint32_t now = millis();
  if (current.success_count > 0) current.success_interval_ms = now - current.last_good_ms;
  current.last_good_ms = now;
  current.success_count++;
  current.sequence++; // Sequence increases ONLY on success.
  current.failures = failures;
  current.sensor_ok = true;
  current.captured_ms = now;
  current.distance_cm = cm;
  xSemaphoreGive(stateMutex);
}

float medianOf(float* x, uint8_t n) {
  float sorted[5];
  for (uint8_t i = 0; i < n; ++i) sorted[i] = x[i];
  for (uint8_t i = 1; i < n; ++i) {
    float v = sorted[i]; int j = i - 1;
    while (j >= 0 && sorted[j] > v) { sorted[j + 1] = sorted[j]; --j; }
    sorted[j + 1] = v;
  }
  return sorted[n / 2];
}

void sensorTask(void*) {
  float history[5] = {};
  uint8_t count = 0, slot = 0;
  uint32_t failures = 0;
  TickType_t lastWake = xTaskGetTickCount();
  for (;;) {
    portENTER_CRITICAL(&echoMux);
    gotRise = false; gotPulse = false; captureEnabled = true;
    portEXIT_CRITICAL(&echoMux);
    digitalWrite(TRIG_PIN, LOW);
    delayMicroseconds(3);
    digitalWrite(TRIG_PIN, HIGH);
    delayMicroseconds(12);
    digitalWrite(TRIG_PIN, LOW);

    uint32_t t0 = micros(), us = 0;
    bool done = false;
    while ((uint32_t)(micros() - t0) < ECHO_TIMEOUT_US) {
      portENTER_CRITICAL(&echoMux);
      if (gotPulse) { us = widthUs; gotPulse = false; done = true; }
      portEXIT_CRITICAL(&echoMux);
      if (done) break;
      vTaskDelay(pdMS_TO_TICKS(1)); // yields CPU; Network Task still runs
    }
    portENTER_CRITICAL(&echoMux);
    captureEnabled = false; gotRise = false;
    portEXIT_CRITICAL(&echoMux);

    float cm = done ? us / 58.0f : NAN;
    bool valid = isfinite(cm) && cm >= MIN_DISTANCE_CM && cm <= MAX_DISTANCE_CM;
    sensorAttempts++;
    if (valid) {
      uint32_t missed = failures;
      if(failures>=8) { count=0; slot=0; }
      failures = 0;
      history[slot] = cm; slot = (slot + 1) % 5;
      if (count < 5) count++;
      float filtered = medianOf(history, count);
      publishReading(filtered, missed);
    } else {
      failures++;
      totalFailures++;
      // Keep last successful reading; never publish FAIL to Cloudflare.
    }
    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(SENSOR_PERIOD_MS));
  }
}

bool authorizedGet(const String& path, JsonDocument& doc) {
  if (WiFi.status() != WL_CONNECTED) return false;
  WiFiClientSecure client;
  client.setCACert(API_CA_PEM);
  client.setTimeout(4);
  HTTPClient http;
  if (!http.begin(client, String(API_BASE) + path)) return false;
  http.setTimeout(3500);
  http.addHeader("Authorization", String("Bearer ") + DEVICE_TOKEN);
  int status = http.GET();
  bool ok = status == 200 && deserializeJson(doc, http.getString()) == DeserializationError::Ok;
  http.end();
  return ok;
}

bool postSnapshot(Snapshot s) {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (!s.sensor_ok || s.sequence == 0 || (uint32_t)(millis()-s.last_good_ms)>3000) return false;
  JsonDocument doc;
  doc["device_id"] = DEVICE_ID;
  doc["sensor_ok"] = s.sensor_ok;
  doc["seq"] = s.sequence;
  doc["boot_id"] = bootId;
  doc["success_interval_ms"] = s.success_interval_ms;
  doc["success_count"] = s.success_count;
  doc["uptime_ms"] = (uint32_t)millis();
  if (s.sensor_ok && isfinite(s.distance_cm)) doc["distance_cm"] = s.distance_cm;
  else doc["distance_cm"] = nullptr;
  String json; serializeJson(doc, json);
  WiFiClientSecure client;
  client.setCACert(API_CA_PEM);
  client.setTimeout(4);
  HTTPClient http;
  if (!http.begin(client, String(API_BASE) + "/api/reading")) return false;
  http.setTimeout(3500);
  http.addHeader("Authorization", String("Bearer ") + DEVICE_TOKEN);
  http.addHeader("Content-Type", "application/json");
  int status = http.POST(json);
  String response = http.getString();
  bool ok = status >= 200 && status < 300;
  if (!ok) {
    Serial.printf("[READING ERROR] HTTP=%d seq=%lu distance=%.2f cm\\n",
                  status, (unsigned long)s.sequence, s.distance_cm);
    Serial.printf("[READING RESPONSE] %s\\n", response.c_str());
  }
  http.end();
  return ok;
}

const char LOCAL_HTML[] PROGMEM = R"PAGE(<!doctype html><html lang="th"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FloodWatch Monitor</title><style>body{font-family:system-ui;background:#eef5f5;color:#203c48;padding:20px}
main{max-width:650px;margin:auto}.card{background:white;padding:20px;border-radius:16px;margin:12px 0}
strong{font-size:2.5rem}input{box-sizing:border-box;padding:12px;width:100%;border:1px solid #cbdada;border-radius:8px}
button{padding:12px;background:#267b8d;color:white;border:0;border-radius:8px;margin:5px 4px 5px 0}
small{color:#526f79}</style></head><body><main><h1>FloodWatch — ESP32</h1>
<div class="card"><div id="state">กำลังโหลด...</div><strong id="distance">--</strong> cm
<p id="stats"></p><p id="cloud"></p>
</div>
<div class="card"><h3>ตั้งค่า Wi-Fi Router (2.4 GHz)</h3><p id="wifi"></p>
<form method="post" action="/local/wifi"><label>SSID</label><input name="ssid" maxlength="32" required>
<label>รหัสผ่าน</label><input name="password" type="password" maxlength="63"><button>บันทึก Wi-Fi</button></form>
<small>เชื่อม AP FloodWatch-Setup แล้วเปิด http://192.168.4.1</small></div></main>
<script>async function refresh(){try{let s=await(await fetch('/local/status',{cache:'no-store'})).json();
document.querySelector('#state').textContent=s.hold?'HOLD_LAST_VALUE':(s.success_count?'SENSOR OK':'WAITING FIRST SUCCESS');
document.querySelector('#distance').textContent=s.success_count?s.distance_cm.toFixed(1):'--';
document.querySelector('#stats').textContent='Success '+s.success_count+' | Fail '+s.failures+' | interval '+s.success_interval_ms+' ms | last good age '+s.last_good_age_ms+' ms';
document.querySelector('#wifi').textContent=s.wifi_connected?'Router IP: '+s.wifi_ip:'Router offline (AP still active)';
document.querySelector('#cloud').textContent='Boot '+s.boot_id+' | Last uploaded seq: '+s.uploaded_sequence;
}catch(e){document.querySelector('#state').textContent='LOCAL MONITOR OFFLINE'}}
setInterval(refresh,1000);refresh();</script></body></html>)PAGE";

static uint32_t uploadedSequence = 0;

void configureLocalWeb() {
  localWeb.on("/",HTTP_GET,[](){localWeb.send_P(200,"text/html; charset=utf-8",LOCAL_HTML);});
  localWeb.on("/local/status",HTTP_GET,[](){
    Snapshot s; if(!copySnapshot(s)){localWeb.send(503,"text/plain","Snapshot busy");return;}
    JsonDocument d;
    d["success_count"]=s.success_count;
    d["distance_cm"]=isfinite(s.distance_cm)?s.distance_cm:0;
    d["success_interval_ms"]=s.success_interval_ms;
    d["last_good_age_ms"]=s.success_count?millis()-s.last_good_ms:0;
    d["hold"]=s.success_count>0 && millis()-s.last_good_ms>600;
    d["failures"]=totalFailures;
    d["wifi_connected"]=WiFi.status()==WL_CONNECTED;
    d["wifi_ip"]=WiFi.localIP().toString();
    d["uploaded_sequence"]=uploadedSequence;
    d["boot_id"]=bootId;
    String json;serializeJson(d,json);localWeb.sendHeader("Cache-Control","no-store");localWeb.send(200,"application/json",json);
  });
  localWeb.on("/local/wifi",HTTP_POST,[](){
    String ssid=localWeb.arg("ssid"),pass=localWeb.arg("password");
    if(!ssid.length()||ssid.length()>32||pass.length()>63){localWeb.send(400,"text/plain","Invalid Wi-Fi settings");return;}
    if(xSemaphoreTake(prefsMutex,pdMS_TO_TICKS(500))!=pdTRUE){localWeb.send(503,"text/plain","Storage busy");return;}
    bool stored=prefs.putString("ssid",ssid)==ssid.length() && prefs.putString("pass",pass)==pass.length();
    xSemaphoreGive(prefsMutex);
    if(!stored){localWeb.send(503,"text/plain","NVS write failed");return;}
    wifiSSID=ssid;wifiPassword=pass;wifiCredentialsChanged=true;
    localWeb.send(200,"text/html; charset=utf-8","<meta charset='utf-8'>บันทึกแล้ว <a href='/'>กลับ</a>");
  });
  localWeb.begin();
}

bool sendConfigAck(uint64_t version, uint32_t seconds, uint32_t uploadSeconds) {
  if(WiFi.status()!=WL_CONNECTED)return false;
  WiFiClientSecure client;client.setCACert(API_CA_PEM);client.setTimeout(4);
  HTTPClient http;
  if(!http.begin(client,String(API_BASE)+"/api/config-ack"))return false;
  http.setTimeout(3500);
  http.addHeader("Authorization",String("Bearer ")+DEVICE_TOKEN);
  http.addHeader("Content-Type","application/json");
  JsonDocument doc;doc["device_id"]=DEVICE_ID;doc["config_version"]=version;doc["heartbeat_seconds"]=seconds;doc["sensor_upload_seconds"]=uploadSeconds;
  String payload;serializeJson(doc,payload);
  int status=http.POST(payload);
  bool ok=status>=200&&status<300;
  if(!ok){
    String response=http.getString();
    Serial.printf("[CONFIG ACK ERROR] HTTP=%d version=%llu response=%s\\n",
                  status,(unsigned long long)version,response.c_str());
  }
  http.end();return ok;
}

bool sendHeartbeat() {
  if(WiFi.status()!=WL_CONNECTED)return false;
  WiFiClientSecure client;client.setCACert(API_CA_PEM);client.setTimeout(4);
  HTTPClient http;
  if(!http.begin(client,String(API_BASE)+"/api/heartbeat"))return false;
  http.setTimeout(3500);
  http.addHeader("Authorization",String("Bearer ")+DEVICE_TOKEN);
  http.addHeader("Content-Type","application/json");
  int status=http.POST(String("{\"device_id\":\"")+DEVICE_ID+"\"}");
  http.end();return status>=200&&status<300;
}

void networkTask(void*) {
  uint32_t lastWifi=0,lastPost=0,lastHeartbeat=0,lastConfig=0;
  uint32_t wifiRetryMs=WIFI_RETRY_MIN_MS; bool configPending=true;
  bool wifiWasConnected=false;
  uint32_t lastHeartbeatSuccessCount=0;
  uint64_t pendingConfigVersion=0, ackedConfigVersion=0; uint32_t lastConfigAckAttempt=0;
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(AP_SSID,AP_PASS);
  configureLocalWeb();
  Serial.printf("AP %s: http://%s\n",AP_SSID,WiFi.softAPIP().toString().c_str());
  if(wifiSSID.length())WiFi.begin(wifiSSID.c_str(),wifiPassword.c_str());
  configTime(0,0,"pool.ntp.org","time.google.com");
  for(;;){
    localWeb.handleClient();
    uint32_t now=millis();
    if(wifiCredentialsChanged){
      wifiCredentialsChanged=false;
      WiFi.disconnect();
      WiFi.begin(wifiSSID.c_str(),wifiPassword.c_str());
      lastWifi=now; wifiRetryMs=WIFI_RETRY_MIN_MS; configPending=true;
    }
    if(WiFi.status()!=WL_CONNECTED){
      wifiWasConnected=false;
      if(wifiSSID.length() && (uint32_t)(now-lastWifi)>=wifiRetryMs){
        lastWifi=now;
        // Do not disconnect an ongoing connection attempt on each loop.
        WiFi.begin(wifiSSID.c_str(),wifiPassword.c_str());
        wifiRetryMs=(wifiRetryMs >= WIFI_RETRY_MAX_MS/2) ? WIFI_RETRY_MAX_MS : wifiRetryMs*2;
      }
      vTaskDelay(pdMS_TO_TICKS(10));continue;
    }
    if(!wifiWasConnected){wifiWasConnected=true;configPending=true;wifiRetryMs=WIFI_RETRY_MIN_MS;}
    // TLS validation needs NTP time; never use setInsecure().
    if(time(nullptr)<1700000000){vTaskDelay(pdMS_TO_TICKS(10));continue;}
    if(configPending || (uint32_t)(now-lastConfig)>=CONFIG_PERIOD_MS){
      configPending=false;
      lastConfig=now;JsonDocument d;
      if(authorizedGet(String("/api/device-config?device=")+DEVICE_ID,d)){
        int seconds=d["heartbeat_seconds"]|1;
        int uploadSeconds=d["sensor_upload_seconds"]|60;
        if(seconds>=1&&seconds<=300 && uploadSeconds>=5&&uploadSeconds<=86400){
          heartbeatPeriodMs=(uint32_t)seconds*1000UL;
          readingSendPeriodMs=(uint32_t)uploadSeconds*1000UL;
          pendingConfigVersion=d["config_version"].as<uint64_t>();
          Serial.printf("CONFIG heartbeat=%lu ms upload=%lu ms version=%llu\n",(unsigned long)heartbeatPeriodMs,(unsigned long)readingSendPeriodMs,(unsigned long long)pendingConfigVersion);
        } else {
          Serial.println("CONFIG ERROR: invalid heartbeat/upload interval; not acknowledging");
        }
      }
    }
    if(pendingConfigVersion>0 && pendingConfigVersion!=ackedConfigVersion && (lastConfigAckAttempt==0 || (uint32_t)(now-lastConfigAckAttempt)>=5000)){
      lastConfigAckAttempt=now;
      if(sendConfigAck(pendingConfigVersion,heartbeatPeriodMs/1000UL,readingSendPeriodMs/1000UL)){
        ackedConfigVersion=pendingConfigVersion;
        Serial.println("CONFIG ACK OK");
      }else Serial.println("CONFIG ACK FAILED (retrying)");
    }
    Snapshot s;
    if(!copySnapshot(s)){
      Serial.println("NETWORK: snapshot busy; retrying");
      vTaskDelay(pdMS_TO_TICKS(10));
      continue;
    }
    if((uint32_t)(now-lastPost)>=readingSendPeriodMs){
      lastPost=now;
      // Upload only a new successful sample; no FAIL rows.
      if(s.sequence>uploadedSequence && (lastUploadAttempt==0 || (uint32_t)(now-lastUploadAttempt)>=uploadBackoffMs)){
        lastUploadAttempt=now;
        bool ok=postSnapshot(s);
        if(ok){uploadedSequence=s.sequence;uploadBackoffMs=1000;}
        else uploadBackoffMs=(uploadBackoffMs>=15000UL)?30000UL:uploadBackoffMs*2;
        Serial.printf("READING %s seq=%lu interval=%lu ms\n",ok?"OK":"FAILED",(unsigned long)s.sequence,(unsigned long)s.success_interval_ms);
      }
    }
    if(now-lastHeartbeat>=heartbeatPeriodMs){
      lastHeartbeat=now;
      // Heartbeat only if a recent successful sensor reading exists.
      if(!s.sensor_ok || s.success_count==0 || (uint32_t)(now-s.last_good_ms)>READING_STALE_MS){
        Serial.println("HEARTBEAT SKIPPED: no fresh successful reading");
        vTaskDelay(pdMS_TO_TICKS(10));continue;
      }
      bool ok=sendHeartbeat();
      Serial.printf("HEARTBEAT %s\n",ok?"OK":"FAILED");
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void setup() {
  Serial.begin(115200);
  delay(150);
  pinMode(TRIG_PIN, OUTPUT); digitalWrite(TRIG_PIN, LOW);
  pinMode(ECHO_PIN, INPUT);
  prefsMutex=xSemaphoreCreateMutex();
  if(!prefsMutex){Serial.println("Preferences mutex failed");abort();}
  prefs.begin("floodwatch", false);
  bootId = esp_random(); if(!bootId) bootId=1;
  wifiSSID = prefs.getString("ssid","");
  wifiPassword = prefs.getString("pass","");
  stateMutex = xSemaphoreCreateMutex();
  if (!stateMutex) { Serial.println("Cannot allocate RTOS resources"); abort(); }
  attachInterrupt(digitalPinToInterrupt(ECHO_PIN), echoEdgeISR, CHANGE);
  if(xTaskCreate(sensorTask, "sensor", 6144, nullptr, 3, nullptr)!=pdPASS ||
     xTaskCreate(networkTask, "network", 12288, nullptr, 1, nullptr)!=pdPASS){Serial.println("Task creation failed");abort();}
}

void loop() { vTaskDelay(pdMS_TO_TICKS(1000)); }
